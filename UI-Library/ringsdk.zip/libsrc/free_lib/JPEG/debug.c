//#define MAKE_SELF_LIB
//#include <ringsdk\dlg.h>

