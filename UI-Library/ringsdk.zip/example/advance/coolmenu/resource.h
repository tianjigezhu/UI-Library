//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TEST_MENU.rc
//
#define IDB_BITMAP1                     1
#define IDD_D                           1
#define IDC_MYICON                      2
#define IDB_BITMAP2                     2
#define IDB_BITMAP3                     3
#define IDB_BITMAP4                     4
#define IDB_ZBZ                         5
#define IDB_TYJX                        6
#define IDB_BUTTONS                     7
#define IDC_EDIT1                       101
#define IDD_TEST_MENU_DIALOG            102
#define IDC_EDIT2                       102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDC_EDIT3                       103
#define IDM_ABOUT                       104
#define IDC_CHECKBOX1                   104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDC_CHECKBOX3                   106
#define IDI_TEST_MENU                   107
#define IDI_SMALL                       108
#define IDC_TEST_MENU                   109
#define IDM_FULLMENU                    110
#define IDR_MAINFRAME                   128
#define IDI_ICON6                       130
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDI_ICON5                       134
#define IDI_ICON1                       135
#define IDR_MENU1                       137
#define IDM_XP                          137
#define IDM_MENU                        991
#define CM_SHOWSELECTBKG                11842
#define CM_SHOWBKG                      11843
#define CM_SHOWICON                     11844
#define CM_TESTPOPITEM1                 11845
#define CM_SHOWCOPYRIGHT                11846
#define CM_SHOWRECT                     11847
#define CM_ADDMENUITEM                  11848
#define CM_DELMENUITEM                  11849
#define CM_EXIT                         11850
#define CM_SHOWBKGCOLOR                 11851
#define CM_TESTPOPITEM2                 11852
#define CM_EXIT2                        18879
#define ID_MENUITEM32779                32779
#define CM_POPUPITEM1                   40001
#define CM_POPUPITEM2                   40002
#define CM_POPUPITEM3                   40003
#define CM_POPUPITEM4                   40004
#define CM_POPUPITEM5                   40005
#define CM_POPUPITEM6                   40006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
