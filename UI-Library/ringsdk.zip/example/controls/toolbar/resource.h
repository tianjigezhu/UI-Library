//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by toolbar.rc
//
#define IDM_MAIN                        101
#define IDI_MAIN                        103
#define IDI_OPEN                        105
#define IDI_NEW                         115
#define IDI_SAVE                        116
#define IDI_EXIT                        117
#define IDI_HELP                        118
#define IDB_BKG                         121
#define IDB_BGBLUE                      126
#define IDB_TOOL                        129
#define IDB_COOL                        130
#define IDB_LINE                        138
#define IDI_SAVEALL                     144
#define IDI_PRINT                       147
#define IDI_REDO                        148
#define IDI_UNDO                        149
#define IDI_CUT                         150
#define IDI_DEL                         151
#define IDI_PASTE                       152
#define IDI_COPY                        153
#define IDI_CLOSE                       167
#define IDI_NEXT                        168
#define IDI_PREV                        169
#define IDI_CASCADE                     170
#define IDI_TILEH                       171
#define IDI_TILEV                       172
#define IDD_DOCKDLG                     174
#define IDC_DEFTOOLBAR                  179
#define IDB_NET                         183
#define IDB_COOLGRAY                    184
#define IDC_LIST1                       1021
#define IDC_TEXT                        1022
#define IDC_ICON1                       1023
#define CM_ALEFT                        33465
#define CM_ACENTER                      33466
#define CM_ARIGHT                       33467
#define CM_BOLD                         33468
#define CM_ITALIC                       33469
#define CM_UNDERLINE                    33470
#define CM_STRIKE                       33471
#define CM_HELP                         33473
#define CM_NEW                          40001
#define CM_OPEN                         40002
#define CM_EXIT                         40003
#define CM_ABOUT                        40004
#define CM_CASCADE                      40032
#define CM_TILEV                        40034
#define CM_TILEH                        40035
#define CM_CLOSEALL                     40037
#define CM_CLOSE                        40040
#define CM_UNDO                         40041
#define CM_REDO                         40042
#define CM_CUT                          40043
#define CM_SAVE                         40047
#define ID_MENUITEM40048                40048
#define CM_SAVEALL                      40049
#define ID_MENUITEM40050                40050
#define CM_PRINT                        40051
#define CM_COPY                         40052
#define CM_PASTE                        40053
#define CM_DELETE                       40054
#define CM_BTN                          40095
#define CM_FLAT                         40096
#define CM_DOCKABLE                     40097
#define CM_DOCKH                        40098
#define CM_DOCKV                        40099
#define CM_NONE                         40100
#define CM_CUSTOM                       40102
#define CM_SETUP                        40103
#define CM_CLOSEWINDOW                  40108
#define CM_NEXT                         40112
#define CM_PREV                         40113

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        185
#define _APS_NEXT_COMMAND_VALUE         40125
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
