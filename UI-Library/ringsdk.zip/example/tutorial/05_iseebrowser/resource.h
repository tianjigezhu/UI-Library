//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by iseebrowser.rc
//
#define IDR_MAINMENU                    101
#define IDI_APP                         102
#define IDB_TOOLBAR                     103
#define IDR_ACCEL                       104
#define IDI_ISEE                        105
#define IDB_LOGO                        106
#define IDD_ABOUT                       107
#define IDB_ABOUT                       108
#define IDB_BKG                         109
#define IDI_COLMARKUP                   111
#define IDI_COLMARKDOWN                 112
#define IDB_VIEWTOOL                    113
#define IDB_NAVTOOL                     114
#define IDC_GRAB                        115
#define IDC_MOVEHAND                    116
#define IDC_ZOOMGLASS                   117
#define IDB_THUMBBKG                    119
#define CM_NEW                          40001
#define CM_ABOUT                        40002
#define CM_CASCADE                      40003
#define CM_OPEN                         40004
#define CM_EXIT                         40005
#define CM_TILEV                        40006
#define CM_TILEH                        40007
#define CM_NEWWINDOW                    40009
#define CM_NEWFOLDER                    40010
#define CM_NEWALBUM                     40011
#define CM_SAVETOALBUM                  40012
#define CM_ADDFAV                       40013
#define CM_SHELLOPEN                    40014
#define CM_SHELLEDIT                    40015
#define CM_SHELLOPENWITH                40016
#define CM_SHELLEDITWITH                40017
#define CM_SHELLSHORTCUT                40018
#define ID_MENUITEM40020                40020
#define CM_CAPTWAIN                     40021
#define CM_PRINT                        40024
#define CM_PRINTSETUP                   40025
#define CM_EDITTIMESTAMP                40026
#define CM_CUT                          40027
#define CM_COPY                         40028
#define CM_COPYIMAGE                    40029
#define CM_PASTE                        40030
#define CM_DELETE                       40031
#define CM_COPYTO                       40032
#define CM_MOVETO                       40033
#define CM_RENAME                       40034
#define CM_BATCHRENAME                  40035
#define CM_SEARCH                       40036
#define ID_MENUITEM40037                40037
#define CM_SELNONE                      40038
#define ID_MENUITEM40039                40039
#define CM_SELALL                       40040
#define CM_SELALLFILE                   40041
#define CM_SELINV                       40042
#define CM_TOOLBAR                      40043
#define CM_STATUSBAR                    40044
#define CM_NAVBAR                       40045
#define CM_PREVWINDOW                   40046
#define CM_FULLSCREEN                   40047
#define CM_VIEWTD                       40048
#define CM_VIEWD                        40049
#define CM_VIEWBIGICON                  40051
#define CM_VIEWSMALLICON                40052
#define CM_VIEWLIST                     40054
#define CM_VIEWDETAIL                   40055
#define CM_SHOWFOLDER                   40057
#define CM_SHOWALBUM                    40058
#define CM_SHOWPIC                      40059
#define CM_SHOWMEDIA                    40060
#define CM_SHOWOTHER                    40061
#define CM_SHOWHIDDEN                   40063
#define CM_COLSIZE                      40064
#define CM_COLTYPE                      40065
#define CM_COLTIME                      40066
#define CM_REFRESH                      40067
#define CM_SLIDESHOW                    40068
#define CM_ROTATE                       40069
#define CM_RESIZE                       40070
#define CM_ADJUSTHSL                    40071
#define CM_WPCENTER                     40072
#define CM_WPTILE                       40073
#define CM_WPSTRETCH                    40074
#define CM_OPTION                       40075
#define CM_SORTEXT                      40076
#define CM_SORTNAME                     40077
#define CM_SORTSIZE                     40078
#define CM_SORTTYPE                     40079
#define CM_SORTTIME                     40080
#define CM_SORTASEC                     40081
#define CM_SORTDESC                     40082

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40083
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
