//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mdi.rc
//
#define IDR_MENU1                       101
#define IDR_MAINMENU                    101
#define IDI_APP                         102
#define IDB_TOOLBAR                     103
#define IDR_ACCEL                       104
#define ID_MENUITEM40001                40001
#define CM_NEW                          40001
#define ID_MENUITEM40002                40002
#define CM_ABOUT                        40002
#define ID_MENUITEM40003                40003
#define CM_CASCADE                      40003
#define CM_OPEN                         40004
#define CM_EXIT                         40005
#define CM_TILEV                        40006
#define CM_TILEH                        40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
